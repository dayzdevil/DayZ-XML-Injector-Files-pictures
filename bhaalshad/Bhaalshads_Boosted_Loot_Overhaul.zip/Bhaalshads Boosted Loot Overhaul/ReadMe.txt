Are you tired of loot spawning in the wrong areas ?
Are you fed up with trying to make matches with the category and usage tags ?
Well these files will solve a lot of the game issues with loot spawning.

https://youtu.be/I8x5boKTSUc 

Updated to 1.14 Check out the new Med tents they added using this method:

https://youtu.be/GUJebQQYWgo

The files to make this work will work on both maps. 

There are extra 2 files that are optional that just make things easier for you. See each file bellow if it is a Required or an Optional one. 
To install just send all the files to your server. for best results a wipe or "soft wipe" 
is suggested as this is a complete overhall of the loot for the game. But it is not required,
at some point the CLE will cycle out all the old loot and make use of these new changes.

All values in types for nominal and min are vanilla settings to get you started.

types.xml
(Required)
All Ammo & Magazines have been set to 100/100
All shelves, floor, and tier tags have been removed
Only using custom usages for items, no categories needed.

The tag <usage name="Special"> is for items that you want at Heli / Dynamic events
You can use just this tag to make the item exclusive or set many to allow for mutiple places including the Heli.

The tag <usage name="DontUse"> is just that. Any item you don no wish to use, remove any usage tag it has and just use this one. No need to set nominals to 0 if it has this tag.

cfgspawnabletypes.xml
(Optional)
I've added many preset items with attachments already set. 
as an example like all guns and vehicles with all the 
attachments they need at 100% chance! 

Many many more additions already done for you

cfglimitsdefinition.xml
(Required)
Only one category to be defined (so game sees the function)
Many custom usage tags replacing vanilla settings

mapgrouppos.xml
(Optional)
file (for Chernarus only) that has all the small green towers added back 
in and ready to spawn loot

mapgroupproto.xml
(Required)
All buildings from both maps are included so this will work on either map
Many loot spawn points were added to buildings that did not have any. 
Basic break down of what each building type uses for loot spawns

Houses
                <usage name="Clothes"/>
                <usage name="FoodDrink"/>
                <usage name="Tools"/>
                <usage name="RepairItems"/>
                <usage name="Weapons"/>
                <usage name="MagsAmmo"/>
                <usage name="Plants"/>

Police
                <usage name="Police"/>
                <usage name="Weapons"/>
                <usage name="FoodDrink"/>
                <usage name="MagsAmmo"/>

FireFighters
                <usage name="FireFighter"/>
                <usage name="FoodDrink"/>

Hospitols
                <usage name="Medical"/>
                <usage name="FoodDrink"/>
                <usage name="Equipment"/>

Contruction Sites / Work Shops / Factories
                <usage name="Industrial"/>
                <usage name="Equipment"/>
                <usage name="Containers"/>
                <usage name="Tools"/>
                <usage name="Exsplosives"/>
                <usage name="RepairItems"/> 
Sheds / Garages
                <usage name="Carparts"/>
                <usage name="Plants"/>
                <usage name="Tools"/>
                <usage name="Equipment"/>
                <usage name="RepairItems"/>
                <usage name="Industrial"/>

Green Houses
                <usage name="Plants"/>

 Military
                <usage name="Military"/>
                <usage name="MilitaryClothes"/>
                <usage name="FoodDrink"/>
                <usage name="Exsplosives"/>
                <usage name="MagsAmmo"/>
                <usage name="Containers"/>
                <usage name="Tools"/>
                <usage name="RepairItems"/>

  Stores
                <usage name="Containers"/>
                <usage name="Clothes"/>
                <usage name="FoodDrink"/>
                <usage name="Tools"/>
                <usage name="RepairItems"/>
                <usage name="Seasonal"/>
                <usage name="Plants"/>
Wrecks Military
                <usage name="Military"/>
                <usage name="MilitaryClothes"/>
                <usage name="FoodDrink"/>
                <usage name="Exsplosives"/>
                <usage name="Special"/>
                <usage name="Attachment"/>
                <usage name="Weapons"/>
                <usage name="MagsAmmo"/>
Office
                <usage name="Equipment"/>
                <usage name="Containers"/>
                <usage name="FoodDrink"/>
                <usage name="Tools"/>


 Stands
                <usage name="FoodDrink"/>
                <usage name="Tools"/>
Pub
                <usage name="FoodDrink"/>
                <usage name="Weapons"/>

Towers
                <usage name="Industrial"/>
                <usage name="Tools"/>

Bus Station
                <usage name="Tools"/>
                <usage name="RepairItems"/>

Wells - Toilets
                <usage name="Clothes"/>
                <usage name="FoodDrink"/>
                <usage name="Tools"/>
                <usage name="RepairItems"/>

Guard Towers
                <usage name="Weapons"/>
                <usage name="MagsAmmo"/>
                <usage name="Police"/>

 LightHouse
                <usage name="Clothes"/>
                <usage name="FoodDrink"/>
                <usage name="MagsAmmo"/>
                <usage name="Weapons"/>
Prison
                <usage name="FoodDrink"/>
                <usage name="Tools"/>
                <usage name="RepairItems"/>
                <usage name="MagsAmmo"/>
                <usage name="Police"/>
                <usage name="Prison"/>

Schools
                <usage name="Equipment"/>
                <usage name="Medical"/>
                <usage name="Clothes"/>
                <usage name="FoodDrink"/>
                <usage name="Seasonal"/>
                <usage name="Plants"/>

Boats
                <usage name="Plants"/>
                <usage name="Clothes"/>
                <usage name="Weapons"/>

Church
                <usage name="Weapons"/>
                <usage name="Containers"/>
                <usage name="Medical"/>
                <usage name="Clothes"/>
                <usage name="FoodDrink"/>
                <usage name="MagsAmmo"/>

 LunaPark
                <usage name="Weapons"/>
                <usage name="Containers"/>
                <usage name="Clothes"/>
                <usage name="FoodDrink"/>
                <usage name="MagsAmmo"/>
                <usage name="Equipment"/>
                <usage name="Seasonal"/> 

So as you can see each type of building has many usage tags. In your types.xml file each item has a usage tag set to it. So by changing or adding a usage to an item you can customize where it will spawn in at. Say you only wanted the Red Sneakers to spawn at military areas (just cause you do lol) you would change the tag from clothes to military. But if you wanted them in military and anywhere clothes spawn, then you would add the military tag to it and leave the clothes tag there as well.
You can even go further by adding more usage tags in the definition file and placing them on key items and buildings to customize your loot even more.